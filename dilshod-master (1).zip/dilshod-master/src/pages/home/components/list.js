import Img1 from 'assets/home/1.png';
import Img2 from 'assets/home/2.png';
import Img3 from 'assets/home/3.png';
import Img4 from 'assets/home/4.png';
import Img5 from 'assets/home/5.png';
import Img6 from 'assets/home/6.png';
import Img7 from 'assets/home/7.png';

export const list = [
  {
    id: 1,
    name: 'AI소프트TV',
    img: Img1,
    link: 'https://www.youtube.com/channel/UCGkMqnKUlRD1OlulfCjPzwQ',
  },
  {
    id: 2,
    name: '입시홍보관',
    img: Img2,
    link: 'https://www.youtube.com/channel/UCGkMqnKUlRD1OlulfCjPzwQ',
  },
  {
    id: 3,
    name: 'K-Cloud',
    img: Img3,
    link: 'https://www.youtube.com/channel/UCGkMqnKUlRD1OlulfCjPzwQ',
  },
  {
    id: 4,
    name: 'K-Cloud',
    img: Img4,
    link: 'https://www.youtube.com/channel/UCGkMqnKUlRD1OlulfCjPzwQ',
  },
  {
    id: 5,
    name: 'K-Cloud',
    img: Img5,
    link: 'https://www.youtube.com/channel/UCGkMqnKUlRD1OlulfCjPzwQ',
  },
  {
    id: 6,
    name: 'K-Cloud',
    img: Img6,
    link: 'https://www.youtube.com/channel/UCGkMqnKUlRD1OlulfCjPzwQ',
  },
  {
    id: 7,
    name: 'K-Cloud',
    img: Img7,
    link: 'https://www.youtube.com/channel/UCGkMqnKUlRD1OlulfCjPzwQ',
  },
];
