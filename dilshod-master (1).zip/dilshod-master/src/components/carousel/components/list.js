import IMG2 from 'assets/carousel/2.jpg';
import IMG1 from 'assets/carousel/1.jpg';

export const CarouselItem = [
  {
    id: 1,
    text1: '미래를 예측하는 학문',
    text2: '강원대학교 AI소프트웨어학과',
    text3: 'Department of Artificial Intelligence & Software',
    img: IMG2,
  },
  {
    id: 2,
    text1: '미래를 예측하는 학문',
    text2: '강원대학교 AI소프트웨어학과',
    text3: 'Department of Artificial Intelligence & Software',
    img: IMG1,
  },
  {
    id: 3,
    text1: '미래를 예측하는 학문',
    text2: '강원대학교 AI소프트웨어학과',
    text3: 'Department of Artificial Intelligence & Software',
    img: IMG2,
  },
  {
    id: 4,
    text1: '미래를 예측하는 학문',
    text2: '강원대학교 AI소프트웨어학과',
    text3: 'Department of Artificial Intelligence & Software',
    img: IMG1,
  },
];
